// Event listener to update displayed length value
const lengthSlider = document.getElementById('length');
const lengthValue = document.getElementById('lengthValue');

lengthSlider.addEventListener('input', function() {
  lengthValue.textContent = lengthSlider.value;
});

document.getElementById('generate').addEventListener('click', function() {
  const passwordLength = parseInt(lengthSlider.value, 10);  // Get the selected length
  const password = generatePassword(passwordLength);
  document.getElementById('password').value = password;
});

document.getElementById('copy').addEventListener('click', function() {
  const passwordField = document.getElementById('password');
  passwordField.select();
  document.execCommand('copy');
});

function generatePassword(length) {
  const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-+=<>?";
  let password = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }
  return password;
}
